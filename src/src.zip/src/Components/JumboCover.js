import React from 'react'
import { Jumbotron, Container } from 'react-bootstrap';
import '../style/jumboCover.css';
const JumboCover = () => {
    return (
        <Jumbotron fluid className="jumbotron bg-cover">
            <h1></h1>
        </Jumbotron>
    )
}
export default Jumbotron;